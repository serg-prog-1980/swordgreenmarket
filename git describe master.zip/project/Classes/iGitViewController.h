//
//  iGitViewController.h
//  iGit
//
//  Created by Scott Chacon on 8/14/08.
//  Copyright __MyCompanyName__ 2008. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface iGitViewController : UIViewController {

}

@end

